﻿using System;
using System.Collections.Generic;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Frogger.Model;

namespace Frogger.Controller
{
    /// <summary>
    ///     Manages the powerUps in the game.
    /// </summary>
    public class PowerUpManager
    {
        #region Data members

        private const int PowerUpSpawnIntervalBySeconds = 5;
        private readonly IList<Lane> lanes;
        private readonly IList<WaterLane> waterLanes;
        private DispatcherTimer powerUpSpawnTimer;
        private Canvas gameCanvasReference;
        private readonly Random random = new Random();
        private const int MaxPowerUpSpawn = 500;
        private const int FlySpeed = 1;

        #endregion

        #region Properties

        /// <summary>
        ///     The only active clock power up
        /// </summary>
        public PowerUp ActiveClockPowerUp { get; private set; }

        /// <summary>
        ///     The only active fly power up
        /// </summary>
        public PowerUp ActiveFlyPowerUp { get; private set; }

        #endregion

        #region Constructors

        #region Constructor

        /// <summary>
        ///     Initializes a new instance of the PowerUpManager class.
        /// </summary>
        /// <param name="lanes">A list of lanes where power ups can move.</param>
        /// <param name="waterLanes"> a list of water lanes where power ups can spawn></param>
        public PowerUpManager(IList<Lane> lanes, IList<WaterLane> waterLanes)
        {
            this.lanes = lanes ?? throw new ArgumentNullException(nameof(lanes));
            this.waterLanes = waterLanes ?? throw new ArgumentNullException(nameof(waterLanes));
        }

        #endregion

        #endregion

        #region Methods

        /// <summary>
        ///     Initializes and places PowerUps on the game canvas for each lane.
        /// </summary>
        /// <param name="gameCanvas">The canvas where power ups will be placed.</param>
        public void InitializePowerUps(Canvas gameCanvas)
        {
            this.gameCanvasReference = gameCanvas;
            this.initializePowerUpSpawnTimer();
        }

        /// <summary>
        ///     Initializes the timer responsible for spawning power ups.
        /// </summary>
        private void initializePowerUpSpawnTimer()
        {
            this.powerUpSpawnTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(PowerUpSpawnIntervalBySeconds)
            };
            this.powerUpSpawnTimer.Tick += this.PowerUpSpawnTimerOnTick;
            this.powerUpSpawnTimer.Start();
        }

        /// <summary>
        ///     Handles the timer tick event to spawn a new power up randomly.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">An EventArgs that contains no event data.</param>
        private void PowerUpSpawnTimerOnTick(object sender, object e)
        {
            this.spawnRandomPowerUp();
        }

        private void spawnRandomPowerUp()
        {
            if (this.random.Next(2) == 0)
            {
                if (this.ActiveClockPowerUp == null)
                {
                    this.ActiveClockPowerUp = this.spawnClockPowerUp();
                }
            }
            else
            {
                if (this.ActiveFlyPowerUp == null)
                {
                    this.ActiveFlyPowerUp = this.spawnFlyPowerUp();
                }
            }
        }

        private PowerUp spawnClockPowerUp()
        {
            var totalLanes = this.lanes.Count + this.waterLanes.Count;
            var laneNumber = this.random.Next(totalLanes);
            var xIndex = this.random.Next(500);
            var clockPowerUp = new PowerUp(PowerUp.PowerUpType.Clock)
            {
                XLocation = xIndex
            };
            if (laneNumber < this.lanes.Count)
            {
                clockPowerUp.YLocation = this.lanes[laneNumber].YPosition;
            }
            else
            {
                var waterLaneIndex = laneNumber - this.lanes.Count;
                clockPowerUp.YLocation = this.waterLanes[waterLaneIndex].WaterYPosition;
            }

            this.gameCanvasReference.Children.Add(clockPowerUp.Sprite);
            return clockPowerUp;
        }

        private PowerUp spawnFlyPowerUp()
        {
            var totalLanes = this.lanes.Count + this.waterLanes.Count;
            var laneNumber = this.random.Next(totalLanes);
            var xIndex = this.random.Next(MaxPowerUpSpawn);
            var flyPowerUp = new PowerUp(PowerUp.PowerUpType.Fly)
            {
                XLocation = xIndex
            };
            if (laneNumber < this.lanes.Count)
            {
                flyPowerUp.YLocation = this.lanes[laneNumber].YPosition;
            }
            else
            {
                var waterLaneIndex = laneNumber - this.lanes.Count;
                flyPowerUp.YLocation = this.waterLanes[waterLaneIndex].WaterYPosition;
            }

            flyPowerUp.MoveDirection =
                this.random.Next(2) == 0 ? GameObject.Direction.Left : GameObject.Direction.Right;
            this.gameCanvasReference.Children.Add(flyPowerUp.Sprite);

            flyPowerUp.MoveGameObject(flyPowerUp.MoveDirection, 1);
            return flyPowerUp;
        }

        /// <summary>
        ///     removes power ups once they are collected or off screen
        /// </summary>
        /// <param name="powerUp"> power up to be removed</param>
        public void RemovePowerUp(PowerUp powerUp)
        {
            if (powerUp == this.ActiveClockPowerUp)
            {
                this.gameCanvasReference.Children.Remove(this.ActiveClockPowerUp.Sprite);
                this.ActiveClockPowerUp = null;
            }
            else if (powerUp == this.ActiveFlyPowerUp)
            {
                this.gameCanvasReference.Children.Remove(this.ActiveFlyPowerUp.Sprite);
                this.ActiveFlyPowerUp = null;
            }
        }

        /// <summary>
        ///     Moves the fly power up
        ///     .
        /// </summary>
        public void MoveFly()
        {
            if (this.ActiveFlyPowerUp != null)
            {
                switch (this.ActiveFlyPowerUp.MoveDirection)
                {
                    case GameObject.Direction.Right:
                        this.ActiveFlyPowerUp.XLocation += FlySpeed;
                        break;
                    case GameObject.Direction.Left:
                        this.ActiveFlyPowerUp.XLocation -= FlySpeed;
                        break;
                }

                Canvas.SetLeft(this.ActiveFlyPowerUp.Sprite, this.ActiveFlyPowerUp.XLocation);
                Canvas.SetTop(this.ActiveFlyPowerUp.Sprite, this.ActiveFlyPowerUp.YLocation);
                if (this.isFlyOffScreen(this.ActiveFlyPowerUp))
                {
                    this.RemovePowerUp(this.ActiveFlyPowerUp);
                }
            }
        }

        private bool isFlyOffScreen(PowerUp flyPowerUp)
        {
            return flyPowerUp.XLocation < 0 ||
                   flyPowerUp.XLocation > this.gameCanvasReference.Width;
        }

        #endregion
    }
}