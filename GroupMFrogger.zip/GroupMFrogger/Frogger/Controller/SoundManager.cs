﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Frogger.Controller
{
    /// <summary>
    ///     Manages the loading and playing of sound effects in the game.
    /// </summary>
    public class SoundManager
    {
        private readonly Dictionary<string, MediaElement> sounds;
        private readonly Dictionary<string, DispatcherTimer> soundTimers;

        /// <summary>
        ///     Initializes a new instance of the <see cref="SoundManager" /> class.
        /// </summary>
        public SoundManager()
        {
            this.sounds = new Dictionary<string, MediaElement>();
            this.soundTimers = new Dictionary<string, DispatcherTimer>();
            this.loadSounds();
        }

        /// <summary>
        ///     Asynchronously loads all sound files.
        /// </summary>
        private async void loadSounds()
        {
            await this.loadSoundAsync("vehicleCollision", @"Assets\Sounds\big-impact-7054.wav");
            await this.loadSoundAsync("waterCollision", @"Assets\Sounds\splash-by-blaukreuz-6261.wav");
            await this.loadSoundAsync("wallCollision", @"Assets\Sounds\ouch-116112.wav");
            await this.loadSoundAsync("timeIsUp", @"Assets\Sounds\buzzer-or-wrong-answer-20582.wav");
            await this.loadSoundAsync("playerInHome", @"Assets\Sounds\congratulations-deep-voice-172193.wav");
            await this.loadSoundAsync("completedLevel", @"Assets\Sounds\click-124467.wav");
            await this.loadSoundAsync("powerUp", @"Assets\Sounds\game-bonus-144751.wav");
            await this.loadSoundAsync("gameOver", @"Assets\Sounds\game-over-38511.wav");
        }

        /// <summary>
        ///     Asynchronously loads a sound file and sets up its MediaElement and DispatcherTimer.
        /// </summary>
        /// <param name="key">The key associated with the sound.</param>
        /// <param name="filepath">The file path of the sound.</param>
        private async Task loadSoundAsync(string key, string filepath)
        {
            try
            {
                var sound = await this.createMediaElement(filepath);
                this.sounds[key] = sound;
                this.soundTimers[key] = this.createTimerForSound(key, sound);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading sound '{key}': {ex.Message}");
            }
        }

        /// <summary>
        ///     Plays a sound associated with the given key.
        /// </summary>
        /// <param name="key">The key of the sound to play.</param>
        public void PlaySound(string key)
        {
            if (this.sounds.TryGetValue(key, out var sound))
            {
                sound.Play();

                if (this.soundTimers.TryGetValue(key, out var timer))
                {
                    timer.Start();
                }
            }
        }

        /// <summary>
        ///     Creates a MediaElement for the given file path.
        /// </summary>
        /// <param name="filepath">The file path of the sound.</param>
        /// <returns>A MediaElement for the sound file.</returns>
        private async Task<MediaElement> createMediaElement(string filepath)
        {
            var sound = new MediaElement
            {
                AutoPlay = false
            };
            var file = await StorageFile.GetFileFromApplicationUriAsync(new Uri("ms-appx:///" + filepath));
            var stream = await file.OpenAsync(FileAccessMode.Read);
            sound.SetSource(stream, file.ContentType);

            return sound;
        }

        /// <summary>
        ///     Creates a DispatcherTimer for the sound with a specified key.
        /// </summary>
        /// <param name="key">The key of the sound.</param>
        /// <param name="sound">The MediaElement of the sound.</param>
        /// <returns>A DispatcherTimer for the sound.</returns>
        private DispatcherTimer createTimerForSound(string key, MediaElement sound)
        {
            var timer = new DispatcherTimer
            {
                Interval = key == "playerInHome" ? TimeSpan.FromSeconds(3) : TimeSpan.FromSeconds(1)
            };
            timer.Tick += (sender, e) =>
            {
                sound.Stop();
                timer.Stop();
            };

            return timer;
        }
    }
}