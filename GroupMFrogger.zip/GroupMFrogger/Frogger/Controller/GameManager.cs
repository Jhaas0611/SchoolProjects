﻿using System;
using System.Linq;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Frogger.Model;

namespace Frogger.Controller
{
    /// <summary>
    ///     Manages the game logic and components for the Frogger game.
    /// </summary>
    public class GameManager
    {
        #region Fields

        private GameTimer gameTimer;
        private PlayerManager playerManager;
        private LaneManager laneManager;
        private VehicleManager vehicleManager;
        private WaterLaneManager waterLaneManager;
        private SafeLandingZoneManager safeLandingZoneManager;
        private readonly SoundManager soundManager;
        private Canvas gameCanvas;
        private PowerUpManager powerUpManager;

        private const int TimerInitialValue = 20;
        private DispatcherTimer scoringLifeTimer;
        private int currentTimerValue;
        private int uncrushabilityTimeLeft;

        private int gameScore;
        private const int NumberOfSafeZones = 5;
        private int currentLevel = 1;
        private int levelsCompleted;
        private bool isUncrushable;
        private const int UncrushableDurationInSeconds = 9;
        private const int MaxLevels = 3;
        private const double LowerYThreshold = 55;
        private const double UpperYThreshold = 305;

        /// <summary>Number of lives at the start of the game</summary>
        public static int StartLives = 4;

        /// <summary>Occurs when score changes.</summary>
        public event Action<int> OnScoreChanged;

        /// <summary>Occurs when lives changes.</summary>
        public event Action<int> OnLivesChanged;

        /// <summary>Occurs when Timer changes.</summary>
        public event Action<int> OnTimerChanged;

        /// <summary> Occurs when game is over</summary>
        public event Action OnGameOver;

        /// <summary>Occurs when the level changes.</summary>
        public event Action<int> OnLevelChanged;

        /// <summary>
        /// </summary>
        public event Action<int> OnUncrushableTimerChanged;

        /// <summary>
        ///     Gets a value indicating whether the game is over.
        /// </summary>
        public bool IsGameOver { get; private set; }

        #endregion

        #region Constructor

        /// <summary>
        ///     Initializes a new instance of the GameManager class.
        /// </summary>
        /// <param name="backgroundHeight">The height of the game background.</param>
        /// <param name="backgroundWidth">The width of the game background.</param>
        public GameManager(double backgroundHeight, double backgroundWidth)
        {
            this.initializeComponents(backgroundHeight, backgroundWidth);
            this.soundManager = new SoundManager();
        }

        /// <summary>
        ///     Initializes game components for the constructor.
        /// </summary>
        /// <param name="backgroundHeight">The height of the game background.</param>
        /// <param name="backgroundWidth">The width of the game background.</param>
        private void initializeComponents(double backgroundHeight, double backgroundWidth)
        {
            this.playerManager = new PlayerManager(backgroundHeight, backgroundWidth);
            this.gameTimer = new GameTimer();
            this.laneManager = new LaneManager();
            this.waterLaneManager = new WaterLaneManager();
            this.safeLandingZoneManager = new SafeLandingZoneManager();

            this.powerUpManager = new PowerUpManager(this.laneManager.Lanes, this.waterLaneManager.WaterLanes);

            this.vehicleManager = new VehicleManager(this.laneManager.Lanes, this.waterLaneManager.WaterLanes);
            this.gameTimer.Tick += this.GameLogicTimerOnTick;
            this.initializeScoringLifeTimer();
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Initializes the game, setting up the game environment and starting the main game timer.
        /// </summary>
        /// <param name="canvas">The canvas on which the game elements are drawn and displayed.</param>
        /// <exception cref="ArgumentNullException">Thrown when the provided canvas is null.</exception>
        public void InitializeGame(Canvas canvas)
        {
            this.gameCanvas = canvas ?? throw new ArgumentNullException(nameof(canvas));
            this.laneManager.InitializeLanes();
            this.waterLaneManager.InitializeWaterLanes();
            this.safeLandingZoneManager.PlaceSafeLandingZones(this.gameCanvas, NumberOfSafeZones);
            this.playerManager.CreateAndPlacePlayer(this.gameCanvas);
            this.vehicleManager.InitializeVehicles(this.gameCanvas);
            this.powerUpManager.InitializePowerUps(this.gameCanvas);
            this.gameTimer.Start();
        }

        /// <summary>
        ///     Moves the player left as long as the game is not over.
        /// </summary>
        public void MovePlayerLeft()
        {
            this.playerManager.RotatePlayerLeft();
            this.playerManager.MovePlayerLeft();
            this.playerManager.AnimatePlayerMovement();
        }

        /// <summary>
        ///     Moves the player right as long as the game is not over.
        /// </summary>
        public void MovePlayerRight()
        {
            this.playerManager.RotatePlayerRight();
            this.playerManager.MovePlayerRight();
            this.playerManager.AnimatePlayerMovement();
        }

        /// <summary>
        ///     Moves the player up as long as the game is not over.
        /// </summary>
        public void MovePlayerUp()
        {
            this.playerManager.RotatePlayerUp();
            this.playerManager.MovePlayerUp();
            this.playerManager.AnimatePlayerMovement();
        }

        /// <summary>
        ///     Moves the player down as long as the game is not over.
        /// </summary>
        public void MovePlayerDown()
        {
            this.playerManager.RotatePlayerDown();
            this.playerManager.MovePlayerDown();
            this.playerManager.AnimatePlayerMovement();
        }

        /// <summary>
        ///     Advances the game state with each timer tick, managing movements and interactions.
        /// </summary>
        private void GameLogicTimerOnTick(object sender, EventArgs e)
        {
            this.vehicleManager.MoveVehicles();
            this.powerUpManager.MoveFly();

            this.handlePlayerOnLog();

            this.handlePlayerScoringOrDeathAtTopShoulder();
            if (this.isPlayerInWaterYRange() && !this.playerManager.IsOnLog)
            {
                this.handleLossOfLife();
                this.soundManager.PlaySound("waterCollision");
            }

            this.handleVehicleCollisionOccurs();
            this.handlePowerUpCollisionOccurs();
        }

        private void handlePlayerOnLog()
        {
            var collidingVehicle = this.getCollidingVehicle();
            if (collidingVehicle != null)
            {
                this.playerManager.IsOnLog = true;
                var directionFactor = collidingVehicle.MoveDirection == GameObject.Direction.Left ? -1 : 1;
                this.playerManager.Player.XLocation += collidingVehicle.SpeedX * directionFactor;
            }
            else
            {
                this.playerManager.IsOnLog = false;
            }
        }

        private Vehicle getCollidingVehicle()
        {
            foreach (var lane in this.waterLaneManager.WaterLanes)
            {
                foreach (var vehicle in lane.Logs)
                {
                    if (this.playerManager.Player.CollisionOccurred(vehicle))
                    {
                        return vehicle;
                    }
                }
            }

            return null;
        }

        private bool isPlayerInWaterYRange() {

            return this.playerManager.Player.YLocation >= LowerYThreshold &&
                   this.playerManager.Player.YLocation <= UpperYThreshold;
        }

        private bool playerMadeItToTopShoulder()
        {
            return this.playerManager.Player.YLocation <= this.playerManager.Player.HighShoulderYLocation;
        }

        private bool checkForVehicleCollisions()
        {
            return this.laneManager.Lanes.SelectMany(lane => lane.Vehicles).Any(vehicle
                => this.playerManager.Player.CollisionOccurred(vehicle));
        }

        private void resetFrogPosition()
        {
            this.playerManager.RotatePlayerUp();
            this.playerManager.SetPlayerToStartPosition();
        }

        private void gameIsOver()
        {
            this.IsGameOver = true;
            this.gameTimer.Stop();
            this.OnGameOver?.Invoke();
            this.scoringLifeTimer.Stop();
            this.soundManager.PlaySound("gameOver");
            this.resetFrogPosition();
        }

        private void handleVehicleCollisionOccurs()
        {
            if (!this.isUncrushable)
            {
                if (this.checkForVehicleCollisions())
                {
                    this.handleLossOfLife();
                    this.soundManager.PlaySound("vehicleCollision");
                }
            }
        }

        private void handlePowerUpCollisionOccurs()
        {
            if (this.checkForBugCollision())
            {
                this.activateUncrushability();
                this.soundManager.PlaySound("powerUp");
            }

            if (this.checkForClockCollision())
            {
                this.currentTimerValue += 10;
                var onOnTimerChanged = this.OnTimerChanged;
                onOnTimerChanged?.Invoke(this.currentTimerValue);

                this.soundManager.PlaySound("powerUp");
            }
        }

        private void activateUncrushability()
        {
            this.isUncrushable = true;
            this.uncrushabilityTimeLeft = UncrushableDurationInSeconds;
            this.OnUncrushableTimerChanged?.Invoke(this.uncrushabilityTimeLeft);
        }

        private void deactivateUncrushability()
        {
            this.isUncrushable = false;
            this.OnUncrushableTimerChanged?.Invoke(0);
        }

        private bool checkForClockCollision()
        {
            if (this.powerUpManager.ActiveClockPowerUp != null &&
                this.playerManager.Player.CollisionOccurred(this.powerUpManager.ActiveClockPowerUp))
            {
                this.powerUpManager.RemovePowerUp(this.powerUpManager.ActiveClockPowerUp);
                return true;
            }

            return false;
        }

        private bool checkForBugCollision()
        {
            if (this.powerUpManager.ActiveFlyPowerUp != null &&
                this.playerManager.Player.CollisionOccurred(this.powerUpManager.ActiveFlyPowerUp))
            {
                this.powerUpManager.RemovePowerUp(this.powerUpManager.ActiveFlyPowerUp);
                return true;
            }

            return false;
        }

        private void handlePlayerScoringOrDeathAtTopShoulder()
        {
            if (this.playerMadeItToTopShoulder())
            {
                if (this.safeLandingZoneManager.IsPlayerInSafeZone(this.playerManager.Player))
                {
                    var pointsToAdd = this.currentTimerValue * 10;
                    this.gameScore += pointsToAdd;
                    this.OnScoreChanged?.Invoke(this.gameScore);
                    this.resetFrogPosition();
                    this.resetTimer();
                    this.checkGameOverByScoring();
                    this.soundManager.PlaySound("playerInHome");
                }
                else
                {
                    this.handleLossOfLife();
                    this.soundManager.PlaySound("wallCollision");
                }
            }
        }

        private void handleLossOfLife()
        {
            StartLives--;
            this.OnLivesChanged?.Invoke(StartLives);
            this.playerManager.BeginDyingAnimation();
            this.resetFrogPosition();
            this.resetTimer();

            if (StartLives == 0)
            {
                this.gameIsOver();
            }
            else
            {
                this.vehicleManager.ResetLanesToInitialVehicles();
            }
        }

        private void initializeScoringLifeTimer()
        {
            this.currentTimerValue = TimerInitialValue;
            this.scoringLifeTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            this.scoringLifeTimer.Tick += this.ScoringLifeTimerOnTick;
            this.scoringLifeTimer.Start();
        }

        private void ScoringLifeTimerOnTick(object sender, object e)
        {
            this.currentTimerValue--;
            this.OnTimerChanged?.Invoke(this.currentTimerValue);

            if (this.currentTimerValue <= 0)
            {
                this.handleLossOfLife();
                this.resetTimer();
                this.soundManager.PlaySound("timeIsUp");
            }

            if (this.isUncrushable)
            {
                this.uncrushabilityTimeLeft--;

                this.OnUncrushableTimerChanged?.Invoke(this.uncrushabilityTimeLeft);

                if (this.uncrushabilityTimeLeft <= 0)
                {
                    this.deactivateUncrushability();
                }
            }
        }

        private void resetTimer()
        {
            this.currentTimerValue = TimerInitialValue;
        }

        private void checkGameOverByScoring()
        {
            if (this.safeLandingZoneManager.AreAllZonesOccupied)
            {
                if (StartLives > 0)
                {
                    this.incrementLevel();
                    this.soundManager.PlaySound("completedLevel");
                }
                else
                {
                    this.gameIsOver();
                }
            }
        }

        private void incrementLevel()
        {
            if (this.currentLevel < MaxLevels)
            {
                this.currentLevel++;
                this.OnLevelChanged?.Invoke(this.currentLevel);

                this.laneManager.UpdateMaxVehiclesPerLane(1);
                this.laneManager.UpdateLaneSpeeds(1);
                this.waterLaneManager.UpdateLaneSpeeds(1);
                this.waterLaneManager.UpdateMaxVehiclesPerLane(1);

                this.resetForNewLevel();
            }
            else
            {
                this.gameIsOver();
            }
        }

        private void resetForNewLevel()
        {
            this.safeLandingZoneManager.ResetSafeZones(this.gameCanvas, NumberOfSafeZones);
            this.playerManager.SetPlayerToStartPosition();
            this.levelsCompleted++;
            this.gameTimer.Start();
        }

        /// <summary>
        ///     Retrieves the number of levels successfully completed by the player in the current game session.
        /// </summary>
        /// <returns>An integer representing the total number of levels completed.</returns>
        public int GetLevelsCompleted()
        {
            return this.levelsCompleted;
        }

        /// <summary>
        ///     Retrieves the current score of the player in the ongoing game session.
        /// </summary>
        /// <returns>An integer representing the player's current score.</returns>
        public int GetCurrentScore()
        {
            return this.gameScore;
        }

        #endregion
    }
}