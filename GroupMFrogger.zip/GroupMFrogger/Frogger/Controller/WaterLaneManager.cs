﻿using System.Collections.Generic;
using System.Linq;
using Frogger.Model;

namespace Frogger.Controller
{
    /// <summary>
    ///     Manages the water lanes in the Frogger game.
    ///     This class is responsible for creating, updating, and managing the behaviors of water lanes.
    ///     Water lanes are areas in the game where players must navigate across water obstacles.
    /// </summary>
    public class WaterLaneManager
    {
        private const int Lane1YPosition = 305;
        private const int LaneYSpacing = 50;
        private const int NumberOfWaterLanes = 5;
        private const double DefaultSpeed = 0.25;
        private const double SpeedIncrement = 0.25;
        private const int LogsInLane1 = 3;
        private const int LogsInLane2 = 4;
        private const int LogsInLane3 = 3;
        private const int LogsInLane4 = 4;
        private const int LogsInLane5 = 3;

        private readonly IList<WaterLane> waterLanes = new List<WaterLane>();

        /// <summary>
        ///     Gets a collection of WaterLane objects managed by the WaterLaneManager.
        /// </summary>
        public IList<WaterLane> WaterLanes => this.waterLanes.ToList();

        /// <summary>
        ///     Constructs a new WaterLaneManager instance and initializes water lanes with default properties.
        /// </summary>
        public WaterLaneManager()
        {
            this.InitializeWaterLanes();
        }

        /// <summary>
        ///     Initializes water lanes for the game with predefined properties such as position, direction, speed, and maximum
        ///     number of logs.
        /// </summary>
        public void InitializeWaterLanes()
        {
            int[] maxLogsPerLane = { LogsInLane1, LogsInLane2, LogsInLane3, LogsInLane4, LogsInLane5 };

            for (var index = 0; index < NumberOfWaterLanes; index++)
            {
                var yPosition = this.calculateLaneYPosition(index);
                var direction = this.determineLaneDirection(index);
                var speed = this.calculateLaneSpeed(index);
                var maxLogs = maxLogsPerLane[index];
                var waterLane = new WaterLane(direction, yPosition, speed, maxLogs);
                this.waterLanes.Add(waterLane);
            }
        }

        private int calculateLaneYPosition(int index)
        {
            return Lane1YPosition - index * LaneYSpacing;
        }

        private GameObject.Direction determineLaneDirection(int index)
        {
            return index % 2 == 0 ? GameObject.Direction.Left : GameObject.Direction.Right;
        }

        private double calculateLaneSpeed(int index)
        {
            return DefaultSpeed + index * SpeedIncrement;
        }

        /// <summary>
        ///     Updates the maximum number of vehicles allowed per lane. This method decrements the current maximum vehicle
        ///     capacity for each lane by a specified number of vehicles.
        /// </summary>
        /// <param name="numOfVehicles">
        ///     The number of additional vehicles to be added to the maximum vehicle capacity of each lane.
        ///     This value is added to the current maximum capacity of each lane.
        /// </param>
        public void UpdateMaxVehiclesPerLane(int numOfVehicles)
        {
            foreach (var lane in this.waterLanes)
            {
                lane.MaxLogs -= numOfVehicles;
            }
        }

        /// <summary>
        ///     Increases the speed of each lane based on the level progression.
        /// </summary>
        /// <param name="additionalSpeed">The additional speed to be added to each lane.</param>
        public void UpdateLaneSpeeds(int additionalSpeed)
        {
            foreach (var lane in this.waterLanes)
            {
                lane.Speed += additionalSpeed;
            }
        }
    }
}