﻿using System.Collections.Generic;
using System.Linq;
using Windows.UI.Xaml.Controls;
using Frogger.Model;
using Frogger.View.Sprites;

namespace Frogger.Controller
{
    /// <summary>
    ///     Manages the safe landing zones for the game.
    /// </summary>
    public class SafeLandingZoneManager
    {
        private const int SafeZoneWidth = 100;
        private readonly IList<SafeLandingZone> safeLandingZones = new List<SafeLandingZone>();

        /// <summary>
        ///     Signifies when the zones have all been visited by player
        /// </summary>
        public bool AreAllZonesOccupied => !this.safeLandingZones.Any();

        /// <summary>
        ///     Places the safe landing zones on the game canvas.
        /// </summary>
        /// <param name="gameCanvas">The game canvas where zones are to be placed.</param>
        /// <param name="numberOfZones">The number of safe zones to create.</param>
        public void PlaceSafeLandingZones(Canvas gameCanvas, int numberOfZones)
        {
            var totalZonesWidth = SafeZoneWidth * numberOfZones;
            var remainingWidth = gameCanvas.Width - totalZonesWidth;
            var baseSpacing = remainingWidth / (numberOfZones + 1);

            for (var index = 0; index < numberOfZones; index++)
            {
                var zoneStartingPoint = baseSpacing + index * (SafeZoneWidth + baseSpacing);

                var safeZoneSprite = new SafeZoneSprite();
                var safeLandingZone = new SafeLandingZone(safeZoneSprite);

                safeLandingZone.YLocation = safeLandingZone.HighShoulderYLocation;
                safeLandingZone.XLocation = zoneStartingPoint;
                safeLandingZone.Width = SafeZoneWidth;

                this.safeLandingZones.Add(safeLandingZone);

                safeZoneSprite.SetValue(Canvas.LeftProperty, zoneStartingPoint);
                gameCanvas.Children.Add(safeZoneSprite);
            }
        }

        /// <summary>
        ///     Checks if the player is inside any of the safe landing zones.
        /// </summary>
        /// <param name="player">The player whose position needs to be checked.</param>
        /// <returns>True if the player is inside a safe zone, false otherwise.</returns>
        public bool IsPlayerInSafeZone(GameObject player)
        {
            foreach (var safeZone in this.safeLandingZones)
            {
                if (this.isPlayerInsideZone(player, safeZone))
                {
                    this.updateZoneAfterPlayerLanding(safeZone);
                    return true;
                }
            }

            return false;
        }

        private bool isPlayerInsideZone(GameObject player, SafeLandingZone safeZone)
        {
            return player.XLocation >= safeZone.XLocation &&
                   player.XLocation + player.Width <= safeZone.XLocation + safeZone.Width;
        }

        private void updateZoneAfterPlayerLanding(SafeLandingZone safeZone)
        {
            safeZone.SafeZoneSprite.ShowVisitedOverlay();
            this.safeLandingZones.Remove(safeZone);
        }

        /// <summary>
        ///     Resets the safe landing zones to their initial state.
        /// </summary>
        public void ResetSafeZones(Canvas gameCanvas, int numberOfZones)
        {
            foreach (var zone in this.safeLandingZones)
            {
                gameCanvas.Children.Remove(zone.SafeZoneSprite);
            }

            this.safeLandingZones.Clear();

            this.PlaceSafeLandingZones(gameCanvas, numberOfZones);
        }
    }
}