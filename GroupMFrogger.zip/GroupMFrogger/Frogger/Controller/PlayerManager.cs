﻿using System;
using System.Collections.Generic;
using Windows.Foundation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Frogger.Model;
using Frogger.View.Sprites;

namespace Frogger.Controller
{
    /// <summary>
    ///     Manages the player in the Frogger game.
    /// </summary>
    public class PlayerManager
    {
        #region Data members

        private const double RotateLeftAngle = -90;
        private const double RotateRightAngle = 90;
        private const double RotateUpAngle = 0;
        private const double RotateDownAngle = 180;
        private const int DyingTickMilliseconds = 250;
        private const int PlayerMovementTickMilliseconds = 50;

        #endregion

        #region Properties

        /// <summary>
        ///     Gets the player character.
        /// </summary>
        public Frog Player { get; private set; }

        /// <summary>
        ///     Boolean for is the player is on a log.
        /// </summary>
        public bool IsOnLog { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the PlayerManager class.
        /// </summary>
        /// <param name="backgroundHeight">The height of the game background.</param>
        /// <param name="backgroundWidth">The width of the game background.</param>
        public PlayerManager(double backgroundHeight, double backgroundWidth)
        {
            this.backgroundHeight = backgroundHeight;
            this.backgroundWidth = backgroundWidth;

            this.dyingAnimationTimer = new DispatcherTimer
                { Interval = TimeSpan.FromMilliseconds(DyingTickMilliseconds) };
            this.playerMovementTimer = new DispatcherTimer
                { Interval = TimeSpan.FromMilliseconds(PlayerMovementTickMilliseconds) };
            this.dyingAnimationTimer.Tick += this.handleDyingAnimationTick;
            this.playerMovementTimer.Tick += this.handleMovementAnimationTick;

            this.dyingAnimationSprites = new List<UserControl>
            {
                new DyingAnimationSprite1(),
                new DyingAnimationSprite2(),
                new DyingAnimationSprite3(),
                new DyingAnimationSprite4()
            };

            this.playerMovementSprites = new List<UserControl>
            {
                new MovingFrogSprite()
            };
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Rotates the player sprite to face left.
        /// </summary>
        public void RotatePlayerLeft()
        {
            this.applyRotationToSprite(this.Player.Sprite, RotateLeftAngle);
            foreach (var sprite in this.playerMovementSprites)
            {
                this.applyRotationToSprite(sprite, RotateLeftAngle);
            }
        }

        /// <summary>
        ///     Rotates the player sprite to face right.
        /// </summary>
        public void RotatePlayerRight()
        {
            this.applyRotationToSprite(this.Player.Sprite, RotateRightAngle);
            foreach (var sprite in this.playerMovementSprites)
            {
                this.applyRotationToSprite(sprite, RotateRightAngle);
            }
        }

        /// <summary>
        ///     Rotates the player sprite to face up.
        /// </summary>
        public void RotatePlayerUp()
        {
            this.applyRotationToSprite(this.Player.Sprite, RotateUpAngle);
            foreach (var sprite in this.playerMovementSprites)
            {
                this.applyRotationToSprite(sprite, RotateUpAngle);
            }
        }

        /// <summary>
        ///     Rotates the player sprite to face down.
        /// </summary>
        public void RotatePlayerDown()
        {
            this.applyRotationToSprite(this.Player.Sprite, RotateDownAngle);
            foreach (var sprite in this.playerMovementSprites)
            {
                this.applyRotationToSprite(sprite, RotateDownAngle);
            }
        }

        private void applyRotationToSprite(UserControl sprite, double angle)
        {
            sprite.RenderTransformOrigin = new Point(0.5, 0.5);
            var rotateTransform = new RotateTransform { Angle = angle };
            sprite.RenderTransform = rotateTransform;
        }

        /// <summary>
        ///     Creates and places the player character on the game canvas.
        /// </summary>
        /// <param name="gameCanvas">The canvas where the game is displayed.</param>
        public void CreateAndPlacePlayer(Canvas gameCanvas)
        {
            this.Player = new Frog();
            gameCanvas.Children.Add(this.Player.Sprite);
            this.initializeDyingSprites(gameCanvas);
            this.initializeMovingSprites(gameCanvas);
            this.SetPlayerToStartPosition();
        }

        /// <summary>
        ///     Sets the player character to the starting position.
        /// </summary>
        public void SetPlayerToStartPosition()
        {
            this.Player.XLocation = this.backgroundWidth / 2 - this.Player.Width / 2;
            this.Player.YLocation = this.backgroundHeight - BottomLaneOffset;
        }

        /// <summary>
        ///     Moves the player character to the left.
        /// </summary>
        public void MovePlayerLeft()
        {
            this.Player.MoveGameObject(GameObject.Direction.Left, this.Player.SpeedX);
        }

        /// <summary>
        ///     Moves the player character to the right.
        /// </summary>
        public void MovePlayerRight()
        {
            this.Player.MoveGameObject(GameObject.Direction.Right, this.Player.SpeedX);
        }

        /// <summary>
        ///     Moves the player character upward.
        /// </summary>
        public void MovePlayerUp()
        {
            this.Player.MoveGameObject(GameObject.Direction.Up, this.Player.SpeedY);
        }

        /// <summary>
        ///     Moves the player character downward.
        /// </summary>
        public void MovePlayerDown()
        {
            this.Player.MoveGameObject(GameObject.Direction.Down, this.Player.SpeedY);
        }

        /// <summary>
        ///     Starts the dying animation for the player, showing a sequence of frames.
        /// </summary>
        public void BeginDyingAnimation()
        {
            this.Player.SetSpeed(0, 0);
            this.currentDyingSpriteIndex = 0;
            this.Player.Sprite.Visibility = Visibility.Collapsed;
            this.dyingAnimationSprites[this.currentDyingSpriteIndex].Visibility = Visibility.Visible;
            this.dyingAnimationTimer.Start();

            foreach (var sprite in this.dyingAnimationSprites)
            {
                Canvas.SetLeft(sprite, this.Player.XLocation);
                Canvas.SetTop(sprite, this.Player.YLocation);
            }
        }

        /// <summary>
        ///     Begins player animation
        /// </summary>
        public void AnimatePlayerMovement()
        {
            this.Player.Sprite.Visibility = Visibility.Collapsed;
            this.playerMovementSprites[0].Visibility = Visibility.Visible;
            Canvas.SetLeft(this.playerMovementSprites[0], this.Player.XLocation);
            Canvas.SetTop(this.playerMovementSprites[0], this.Player.YLocation);
            Canvas.SetZIndex(this.playerMovementSprites[0], 1);
            this.playerMovementTimer.Start();
        }

        private void handleMovementAnimationTick(object sender, object e)
        {
            this.playerMovementTimer.Stop();
            this.finishMovingAnimation();
        }

        private void finishMovingAnimation()
        {
            this.playerMovementSprites[0].Visibility = Visibility.Collapsed;
            this.Player.Sprite.Visibility = Visibility.Visible;
        }

        /// <summary>
        ///     Displays the next frame in the dying animation sequence.
        /// </summary>
        public void NextDyingFrame()
        {
            if (this.currentDyingSpriteIndex < this.dyingAnimationSprites.Count - 1)
            {
                this.dyingAnimationSprites[this.currentDyingSpriteIndex].Visibility = Visibility.Collapsed;
                this.currentDyingSpriteIndex++;
                this.dyingAnimationSprites[this.currentDyingSpriteIndex].Visibility = Visibility.Visible;
            }
            else
            {
                this.finishDyingAnimation();
            }
        }

        /// <summary>
        ///     Handles the timer tick for the dying animation, advancing the frame or completing the animation.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">An EventArgs that contains no event data.</param>
        private void handleDyingAnimationTick(object sender, object e)
        {
            if (this.currentDyingSpriteIndex == this.dyingAnimationSprites.Count - 1)
            {
                this.dyingAnimationTimer.Stop();
                this.finishDyingAnimation();
            }
            else
            {
                this.NextDyingFrame();
            }
        }

        private void finishDyingAnimation()
        {
            this.dyingAnimationSprites[this.currentDyingSpriteIndex].Visibility = Visibility.Collapsed;

            this.SetPlayerToStartPosition();
            this.RotatePlayerUp();

            this.Player.Sprite.Visibility = Visibility.Visible;
            this.Player.SetSpeed(PlayerSpeed, PlayerSpeed);
        }

        private void initializeDyingSprites(Canvas gameCanvas)
        {
            foreach (var sprite in this.dyingAnimationSprites)
            {
                sprite.Visibility = Visibility.Collapsed;
                gameCanvas.Children.Add(sprite);
            }
        }

        private void initializeMovingSprites(Canvas gameCanvas)
        {
            foreach (var sprite in this.playerMovementSprites)
            {
                sprite.Visibility = Visibility.Collapsed;
                gameCanvas.Children.Add(sprite);
            }
        }

        #endregion

        #region Fields

        private readonly double backgroundHeight;
        private readonly double backgroundWidth;
        private const int BottomLaneOffset = 145;
        private const int PlayerSpeed = 50;

        private readonly IList<UserControl> dyingAnimationSprites;
        private readonly IList<UserControl> playerMovementSprites;
        private int currentDyingSpriteIndex;
        private readonly DispatcherTimer dyingAnimationTimer;
        private readonly DispatcherTimer playerMovementTimer;

        #endregion
    }
}