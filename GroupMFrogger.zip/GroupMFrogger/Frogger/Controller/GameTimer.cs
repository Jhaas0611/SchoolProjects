﻿using System;
using Windows.UI.Xaml;

namespace Frogger.Controller
{
    /// <summary>
    ///     Represents a game timer that triggers the Tick event at regular intervals.
    /// </summary>
    public class GameTimer
    {
        /// <summary>
        ///     Occurs when the timer ticks.
        /// </summary>
        public event EventHandler Tick;

        private readonly DispatcherTimer timer;
        private const int TimerTickMilliseconds = 15;

        /// <summary>
        ///     Initializes a new instance of the GameTimer class.
        /// </summary>
        public GameTimer()
        {
            this.timer = new DispatcherTimer();
            this.timer.Tick += this.OnTimerTick;
            this.timer.Interval = new TimeSpan(0, 0, 0, 0, TimerTickMilliseconds);
        }

        private void OnTimerTick(object sender, object e)
        {
            this.Tick?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        ///     Starts the game timer.
        /// </summary>
        public void Start()
        {
            this.timer.Start();
        }

        /// <summary>
        ///     Stops the game timer.
        /// </summary>
        public void Stop()
        {
            this.timer.Stop();
        }
    }
}