﻿using System.Collections.Generic;
using System.Linq;
using Frogger.Model;

namespace Frogger.Controller
{
    /// <summary>
    ///     Manages the lanes in the Frogger game.
    /// </summary>
    public class LaneManager
    {
        private const int Lane1YPosition = 605;
        private const int LaneYSpacing = 50;
        private const int NumberOfLanes = 5;
        private const double DefaultSpeed = .5;
        private const double SpeedIncrement = .25;

        private readonly IList<Lane> lanes = new List<Lane>();

        /// <summary>
        ///     Gets a copy of the lanes to be accessed in GameManager
        /// </summary>
        public IList<Lane> Lanes => this.lanes.ToList();

        /// <summary>
        ///     Initializes a new instance of the LaneManager class.
        /// </summary>
        public LaneManager()
        {
            this.InitializeLanes();
        }

        /// <summary>
        ///     Initializes the lanes in the game with default settings.
        /// </summary>
        public void InitializeLanes()
        {
            int[] maxVehiclesPerLane = { 2, 1, 2, 1, 2 };

            for (var index = 0; index < NumberOfLanes; index++)
            {
                var laneYPosition = this.calculateLaneYPosition(index);
                var direction = this.determineLaneDirection(index);
                var laneSpeed = this.calculateLaneSpeed(index);
                var maxVehicles = maxVehiclesPerLane[index];
                var newLane = new Lane(direction, laneYPosition, laneSpeed, maxVehicles);
                this.lanes.Add(newLane);
            }
        }

        private int calculateLaneYPosition(int index)
        {
            return Lane1YPosition - index * LaneYSpacing;
        }

        private GameObject.Direction determineLaneDirection(int index)
        {
            return index % 2 == 0 ? GameObject.Direction.Left : GameObject.Direction.Right;
        }

        private double calculateLaneSpeed(int index)
        {
            return DefaultSpeed + index * SpeedIncrement;
        }

        /// <summary>
        ///     Updates the maximum number of vehicles allowed per lane. This method increments the current maximum vehicle
        ///     capacity for each lane by a specified additional number of vehicles.
        /// </summary>
        /// <param name="additionalVehicles">
        ///     The number of additional vehicles to be added to the maximum vehicle capacity of each
        ///     lane. This value is added to the current maximum capacity of each lane.
        /// </param>
        public void UpdateMaxVehiclesPerLane(int additionalVehicles)
        {
            foreach (var lane in this.lanes)
            {
                lane.MaxVehicles += additionalVehicles;
            }
        }

        /// <summary>
        ///     Increases the speed of each lane based on the level progression.
        /// </summary>
        /// <param name="additionalSpeed">The additional speed to be added to each lane.</param>
        public void UpdateLaneSpeeds(int additionalSpeed)
        {
            foreach (var lane in this.lanes)
            {
                lane.Speed += additionalSpeed;
            }
        }

        /// <summary>
        ///     Resets the lanes
        /// </summary>
        public void ResetLanes()
        {
            foreach (var lane in this.lanes)
            {
                lane.Reset();
            }
        }
    }
}