﻿using System;
using System.Collections.Generic;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Frogger.Model;

namespace Frogger.Controller
{
    /// <summary>
    ///     Manages the vehicles in the game.
    /// </summary>
    public class VehicleManager
    {
        private readonly IList<Lane> lanes;
        private readonly IList<WaterLane> waterLanes;
        private DispatcherTimer vehicleSpawnTimer;
        private const int VehicleSpawnIntervalBySeconds = 5;
        private Canvas gameCanvasReference;

        private readonly List<(int numberOfVehicles, Vehicle.VehicleType type, GameObject.Direction direction)>
            laneConfigurations =
                new List<(int numberOfVehicles, Vehicle.VehicleType type, GameObject.Direction direction)>
                {
                    (1, Vehicle.VehicleType.Car, GameObject.Direction.Left),
                    (1, Vehicle.VehicleType.Truck, GameObject.Direction.Right),
                    (1, Vehicle.VehicleType.Suv, GameObject.Direction.Left),
                    (1, Vehicle.VehicleType.Truck, GameObject.Direction.Left),
                    (1, Vehicle.VehicleType.Car, GameObject.Direction.Right)
                };

        private readonly List<(int numberOfVehicles, Vehicle.VehicleType type, GameObject.Direction direction)>
            waterLaneConfigurations =
                new List<(int numberOfVehicles, Vehicle.VehicleType type, GameObject.Direction direction)>
                {
                    (3, Vehicle.VehicleType.LargeLog, GameObject.Direction.Left),
                    (4, Vehicle.VehicleType.SmallLog, GameObject.Direction.Right),
                    (3, Vehicle.VehicleType.LargeLog, GameObject.Direction.Left),
                    (4, Vehicle.VehicleType.SmallLog, GameObject.Direction.Left),
                    (3, Vehicle.VehicleType.LargeLog, GameObject.Direction.Right)
                };

        #region Constructor

        /// <summary>
        ///     Initializes a new instance of the VehicleManager class.
        /// </summary>
        /// <param name="lanes">A list of lanes where vehicles can move.</param>
        /// <param name="waterLanes">A list of waterLanes where vehicles can float.</param>
        public VehicleManager(IList<Lane> lanes, IList<WaterLane> waterLanes)
        {
            this.lanes = lanes ?? throw new ArgumentNullException(nameof(lanes));
            this.waterLanes = waterLanes ?? throw new ArgumentNullException(nameof(waterLanes));
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Initializes vehicles in both regular and water lanes on the provided game canvas, according to the configured
        ///     specifications.
        /// </summary>
        /// <param name="gameCanvas">The canvas where the vehicles will be displayed and move.</param>
        public void InitializeVehicles(Canvas gameCanvas)
        {
            this.gameCanvasReference = gameCanvas;

            for (var index = 0; index < this.lanes.Count; index++)
            {
                var config = this.laneConfigurations[index];
                this.lanes[index].PlaceVehicles(gameCanvas, config.numberOfVehicles, config.type, config.direction);
            }

            for (var i = 0; i < this.waterLanes.Count; i++)
            {
                var config = this.waterLaneConfigurations[i];
                this.waterLanes[i].PlaceLogs(gameCanvas, config.numberOfVehicles, config.type, config.direction);
            }

            this.initializeVehicleSpawnTimer();
        }

        /// <summary>
        ///     Initializes the timer responsible for spawning vehicles.
        /// </summary>
        private void initializeVehicleSpawnTimer()
        {
            this.vehicleSpawnTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(VehicleSpawnIntervalBySeconds)
            };
            this.vehicleSpawnTimer.Tick += this.VehicleSpawnTimerOnTick;
            this.vehicleSpawnTimer.Start();
        }

        /// <summary>
        ///     Handles the timer tick event to spawn a new vehicle on each lane.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">An EventArgs that contains no event data.</param>
        private void VehicleSpawnTimerOnTick(object sender, object e)
        {
            for (var index = 0; index < this.lanes.Count; index++)
            {
                var config = this.laneConfigurations[index];
                this.lanes[index].PlaceVehicles(this.gameCanvasReference, 1, config.type, config.direction);
                this.waterLanes[index].PlaceLogs(this.gameCanvasReference, 1, config.type, config.direction);
            }
        }

        /// <summary>
        ///     Moves all the vehicles in each lane.
        /// </summary>
        public void MoveVehicles()
        {
            (this.lanes as List<Lane>)?.ForEach(eachLane => eachLane.MoveVehicles());
            (this.waterLanes as List<WaterLane>)?.ForEach(eachWaterLane => eachWaterLane.MoveLogs());
        }

        /// <summary>
        ///     Resets each lane to contain only one vehicle.
        /// </summary>
        public void ResetLanesToInitialVehicles()
        {
            for (var index = 0; index < this.waterLanes.Count; index++)
            {
                var config = this.waterLaneConfigurations[index];
                this.waterLanes[index].Reset();
                this.waterLanes[index].PlaceLogs(this.gameCanvasReference, 4, config.type, config.direction);
            }

            for (var i = 0; i < this.lanes.Count; i++)
            {
                var config = this.laneConfigurations[i];
                this.lanes[i].Reset();
                this.lanes[i].PlaceVehicles(this.gameCanvasReference, 1, config.type, config.direction);
            }
        }

        #endregion
    }
}