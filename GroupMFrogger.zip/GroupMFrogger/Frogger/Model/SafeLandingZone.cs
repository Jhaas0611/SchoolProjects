﻿using Frogger.View.Sprites;

namespace Frogger.Model
{
    /// <summary>
    ///     Represents a safe zone where the player can safely land.
    /// </summary>
    public class SafeLandingZone : GameObject
    {
        /// <summary>
        ///     Gets the sprite associated with the safe zone.
        /// </summary>
        public SafeZoneSprite SafeZoneSprite { get; }

        #region Constructor

        /// <summary>
        ///     Initializes a new instance of the <see cref="SafeLandingZone" /> class.
        /// </summary>
        /// <param name="safeZoneSprite">The sprite associated with the safe zone.</param>
        public SafeLandingZone(SafeZoneSprite safeZoneSprite)
        {
            Sprite = safeZoneSprite;
            this.SafeZoneSprite = safeZoneSprite;
        }

        #endregion
    }
}