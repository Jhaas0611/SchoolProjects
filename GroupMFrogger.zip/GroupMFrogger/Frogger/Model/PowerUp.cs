﻿using System;
using Frogger.View.Sprites;

namespace Frogger.Model
{
    /// <summary>
    ///     Represents a Power Up in the Frogger game.
    /// </summary>
    /// <seealso cref="Frogger.Model.GameObject" />
    public class PowerUp : GameObject
    {
        /// <summary>
        ///     Enumeration representing types of vehicles.
        /// </summary>
        public enum PowerUpType
        {
            /// <summary>
            ///     Enum representing a Clock
            /// </summary>
            Clock,

            /// <summary>
            ///     Enum representing a Fly
            /// </summary>
            Fly
        }

        /// <summary>
        ///     Gets or sets the movement direction of the vehicle.
        /// </summary>
        public Direction MoveDirection { get; set; }

        /// <summary>
        ///     Initializes a new instance of the Vehicle class.
        /// </summary>
        /// <param name="type">The type of vehicle (Car or Truck).</param>
        public PowerUp(PowerUpType type)
        {
            switch (type)
            {
                case PowerUpType.Clock:
                    Sprite = new ClockSprite();
                    break;
                case PowerUpType.Fly:
                    Sprite = new FlySprite();
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(type), type, null);
            }
        }

        /// <summary>
        ///     Moves the vehicle in the specified direction by a certain distance.
        /// </summary>
        /// <param name="direction">The direction in which to move the vehicle.</param>
        /// <param name="distance">The distance by which to move the vehicle.</param>
        public override void MoveGameObject(Direction direction, double distance)
        {
            base.MoveGameObject(direction, distance);
            this.handlePowerUpWrappingAround();
        }

        private void handlePowerUpWrappingAround()
        {
            switch (this.MoveDirection)
            {
                case Direction.Left when XLocation - Width <= 0:
                    XLocation = BackgroundWidth;
                    break;
                case Direction.Right when XLocation >= BackgroundWidth:
                    XLocation = 0 - Width;
                    break;
            }
        }
    }
}