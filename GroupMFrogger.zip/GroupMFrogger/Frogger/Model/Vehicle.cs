﻿using System;
using Windows.Foundation;
using Windows.UI.Xaml.Media;
using Frogger.View.Sprites;

namespace Frogger.Model
{
    /// <summary>
    ///     Represents a vehicle in the Frogger game.
    /// </summary>
    /// <seealso cref="Frogger.Model.GameObject" />
    public class Vehicle : GameObject
    {
        /// <summary>
        ///     Enumeration representing types of vehicles.
        /// </summary>
        public enum VehicleType
        {
            /// <summary>
            ///     Enum representing a Car
            /// </summary>
            Car,

            /// <summary>
            ///     Enum representing a Truck
            /// </summary>
            Truck,

            /// <summary>
            ///     Enum representing a SUV
            /// </summary>
            Suv,

            /// <summary>
            ///     Enum representing a large log
            /// </summary>
            LargeLog,

            /// <summary>
            ///     Enum representing a small log
            /// </summary>
            SmallLog
        }

        /// <summary>
        ///     Gets or sets the movement direction of the vehicle.
        /// </summary>
        public Direction MoveDirection { get; set; }

        /// <summary>
        ///     Initializes a new instance of the Vehicle class.
        /// </summary>
        /// <param name="type">The type of vehicle (Car or Truck).</param>
        public Vehicle(VehicleType type)
        {
            switch (type)
            {
                case VehicleType.Car:
                    Sprite = new CarSprite();
                    break;
                case VehicleType.Truck:
                    Sprite = new TruckSprite();
                    break;
                case VehicleType.Suv:
                    Sprite = new SuvSprite();
                    break;
                case VehicleType.LargeLog:
                    Sprite = new LargeLogSprite();
                    break;
                case VehicleType.SmallLog:
                    Sprite = new SmallLogSprite();
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(type), type, null);
            }
        }

        /// <summary>
        ///     Moves the vehicle in the specified direction by a certain distance.
        /// </summary>
        /// <param name="direction">The direction in which to move the vehicle.</param>
        /// <param name="distance">The distance by which to move the vehicle.</param>
        public override void MoveGameObject(Direction direction, double distance)
        {
            base.MoveGameObject(direction, distance);
            this.handleVehicleWrappingAround();
            this.updateSpriteTransformation();
        }

        private void handleVehicleWrappingAround()
        {
            switch (this.MoveDirection)
            {
                case Direction.Left when XLocation + Width < 0:
                    XLocation = BackgroundWidth;
                    break;
                case Direction.Right when XLocation > BackgroundWidth:
                    XLocation = 0 - Width;
                    break;
            }
        }

        private void updateSpriteTransformation()
        {
            switch (this.MoveDirection)
            {
                case Direction.Left:
                    this.resetSpriteTransformation();
                    break;
                case Direction.Right:
                    this.flipSpriteHorizontally();
                    break;
            }
        }

        private void resetSpriteTransformation()
        {
            if (Sprite != null)
            {
                Sprite.RenderTransform = null;
            }
        }

        private void flipSpriteHorizontally()
        {
            if (Sprite != null)
            {
                Sprite.RenderTransformOrigin = new Point(0.5, 0.5);
                Sprite.RenderTransform = new ScaleTransform { ScaleX = -1 };
            }
        }
    }
}