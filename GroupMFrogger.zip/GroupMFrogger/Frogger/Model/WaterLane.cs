﻿using System.Collections.Generic;
using Windows.UI.Xaml.Controls;
using static Frogger.Model.GameObject;

namespace Frogger.Model
{
    /// <summary>
    ///     Represents a water lane in the Frogger game.
    /// </summary>
    public class WaterLane
    {
        /// <summary>
        ///     Gets or sets the speed at which logs move in the water lane.
        /// </summary>

        public double Speed { get; set; }

        /// <summary>
        ///     Internal copy of the list of vehicles (logs) present in the water lane.
        /// </summary>
        public IList<Vehicle> LogsCopy = new List<Vehicle>();

        /// <summary>
        ///     Gets an enumerable collection of logs currently in the water lane.
        /// </summary>
        public IEnumerable<Vehicle> Logs => this.LogsCopy;

        /// <summary>
        ///     Gets or sets the direction of flow of the logs in the water lane.
        /// </summary>
        public Direction FlowDirection { get; set; }

        /// <summary>
        ///     Gets or sets the Y-axis position of the water lane in the game canvas.
        /// </summary>

        public int WaterYPosition { get; set; }

        private const int DefaultMaxLogs = 3;
        private const int LogSpread = 100;

        /// <summary>
        ///     Gets or sets the maximum number of logs that can be present in the water lane at any time.
        /// </summary>
        public int MaxLogs { get; set; }

        private const int LogGap = 105;

        /// <summary>
        ///     Reference to the game canvas where the water lane and its logs are displayed.
        /// </summary>
        public Canvas GameCanvasReference;

        /// <summary>
        ///     Initializes a new instance of the WaterLane class with specified properties.
        /// </summary>
        /// <param name="flowDirection">The direction in which logs in the lane will flow.</param>
        /// <param name="waterYPosition">The Y-axis position of the water lane in the game canvas.</param>
        /// <param name="baseSpeed">The base speed of logs moving in the lane.</param>
        /// <param name="maxLogs">The maximum number of logs allowed in the lane. Default value is set by DefaultMaxLogs constant.</param>
        public WaterLane(Direction flowDirection, int waterYPosition, double baseSpeed, int maxLogs = DefaultMaxLogs)
        {
            this.FlowDirection = flowDirection;
            this.WaterYPosition = waterYPosition;
            this.Speed = baseSpeed;
            this.MaxLogs = maxLogs;
        }

        /// <summary>
        ///     Adds a log to the water lane and the game canvas, if the maximum log count is not exceeded.
        /// </summary>
        /// <param name="log">The log (vehicle) to be added to the water lane.</param>
        /// <param name="gameCanvas">The canvas where the log is to be displayed.</param>
        public void AddLog(Vehicle log, Canvas gameCanvas)
        {
            if (this.LogsCopy.Count >= this.MaxLogs)
            {
                return;
            }

            log.YLocation = this.WaterYPosition;
            gameCanvas.Children.Add(log.Sprite);
            this.LogsCopy.Add(log);
        }

        /// <summary>
        ///     Places a specified number of logs of a certain type and moving in a specific direction in the water lane.
        /// </summary>
        /// <param name="gameCanvas">The game canvas where the logs are to be placed.</param>
        /// <param name="numberOfLogs">The number of logs to place in the lane.</param>
        /// <param name="type">The type of the vehicle to be used as logs.</param>
        /// <param name="direction">The direction in which the logs will move.</param>
        public void PlaceLogs(Canvas gameCanvas, int numberOfLogs, Vehicle.VehicleType type, Direction direction)
        {
            this.GameCanvasReference = gameCanvas;

            var startPosition = direction == Direction.Left ? gameCanvas.Width : -LogSpread;
            for (var i = 0; i < numberOfLogs; i++)
            {
                var log = new Vehicle(type)
                {
                    MoveDirection = direction,
                    XLocation = startPosition
                };
                this.AddLog(log, gameCanvas);
                startPosition += (direction == Direction.Left ? -1 : 1) * (log.Width + LogGap);
            }
        }

        /// <summary>
        ///     Moves all logs in the water lane according to the lane's speed and flow direction.
        /// </summary>
        public void MoveLogs()
        {
            foreach (var log in this.Logs)
            {
                log.SetSpeed(this.Speed, 0);
                log.MoveGameObject(log.MoveDirection, this.Speed);
            }
        }

        /// <summary>
        ///     Moves all logs in the water lane according to the lane's speed and flow direction.
        /// </summary>
        public void Reset()
        {
            foreach (var log in this.LogsCopy)
            {
                this.GameCanvasReference.Children.Remove(log.Sprite);
            }

            this.LogsCopy.Clear();
        }
    }
}