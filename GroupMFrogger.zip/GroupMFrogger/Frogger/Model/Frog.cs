﻿using System;
using Windows.UI.Xaml.Controls;
using Frogger.View.Sprites;

namespace Frogger.Model
{
    /// <summary>
    ///     Defines the frog model
    /// </summary>
    /// <seealso cref="Frogger.Model.GameObject" />
    public class Frog : GameObject
    {
        #region Data members

        private const int SpeedXDirection = 50;
        private const int SpeedYDirection = 50;
        private const int BackgroundLeftXLocation = 0;

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="Frog" /> class.
        /// </summary>
        public Frog()
        {
            Sprite = new FrogSprite();
            Canvas.SetZIndex(Sprite, 2);
            SetSpeed(SpeedXDirection, SpeedYDirection);
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Moves the frog in the specified direction by a certain distance.
        /// </summary>
        /// <param name="direction">The direction in which to move the frog.</param>
        /// <param name="distance">The distance by which to move the frog.</param>
        public override void MoveGameObject(Direction direction, double distance)
        {
            switch (direction)
            {
                case Direction.Right:
                    if (XLocation + Width + distance <= BackgroundWidth)
                    {
                        base.MoveGameObject(direction, distance);
                    }

                    break;

                case Direction.Left:
                    if (XLocation - distance >= BackgroundLeftXLocation)
                    {
                        base.MoveGameObject(direction, distance);
                    }

                    break;

                case Direction.Up:
                    if (YLocation - distance >= HighShoulderYLocation)
                    {
                        base.MoveGameObject(direction, distance);
                    }

                    break;

                case Direction.Down:
                    if (YLocation + Height + distance <= LowShoulderYLocation + 50)
                    {
                        base.MoveGameObject(direction, distance);
                    }

                    break;

                default:
                    throw new ArgumentOutOfRangeException(nameof(direction), "Invalid direction.");
            }
        }

        #endregion
    }
}