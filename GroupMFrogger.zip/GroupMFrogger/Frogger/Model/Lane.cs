﻿using System.Collections.Generic;
using Windows.UI.Xaml.Controls;
using static Frogger.Model.GameObject;

namespace Frogger.Model
{
    /// <summary>
    ///     Represents a lane in the Frogger game.
    /// </summary>
    public class Lane
    {
        /// <summary>
        ///     Gets or sets the current speed of the lane.
        /// </summary>
        public double Speed { get; set; }

        /// <summary>
        ///     Gets or sets the list of vehicles in the lane.
        /// </summary>
        public IList<Vehicle> VehiclesCopy = new List<Vehicle>();

        /// <summary>
        ///     Copy of Vehicles
        /// </summary>
        public IEnumerable<Vehicle> Vehicles => this.VehiclesCopy;

        /// <summary>
        ///     Gets or sets the direction in which the lane's vehicles move.
        /// </summary>
        public Direction MoveDirection { get; set; }

        /// <summary>
        ///     Gets or sets the Y position of the lane on the game screen.
        /// </summary>
        public int YPosition { get; set; }

        private const int DefaultMaxVehicles = 2;

        /// <summary>
        ///     Max number of vehicles in a lane
        /// </summary>
        public int MaxVehicles { get; set; }

        private const int BaseGap = 50;

        /// <summary>
        ///     Game canvas for objects
        /// </summary>
        public Canvas GameCanvasReference;

        private const int VehicleSpread = 100;

        /// <summary>
        ///     Initializes a new instance of the Lane class.
        /// </summary>
        /// <param name="direction">The direction in which the lane's vehicles move.</param>
        /// <param name="yPosition">The Y position of the lane on the game screen.</param>
        /// <param name="baseSpeed">The base speed of the lane.</param>
        /// <param name="maxVehicles"></param>
        public Lane(Direction direction, int yPosition, double baseSpeed, int maxVehicles = DefaultMaxVehicles)
        {
            this.MoveDirection = direction;
            this.YPosition = yPosition;
            this.Speed = baseSpeed;
            this.MaxVehicles = maxVehicles;
        }

        /// <summary>
        /// </summary>
        /// <param name="vehicle"></param>
        /// <param name="gameCanvas"></param>
        public void AddVehicle(Vehicle vehicle, Canvas gameCanvas)
        {
            if (this.VehiclesCopy.Count >= this.MaxVehicles)
            {
                return;
            }

            var startPosition = this.findSafeSpawn(vehicle, gameCanvas);
            vehicle.XLocation = startPosition;
            this.VehiclesCopy.Add(vehicle);
            vehicle.YLocation = this.YPosition;
            gameCanvas.Children.Add(vehicle.Sprite);
        }

        private double findSafeSpawn(Vehicle newVehicle, Canvas gameCanvas)
        {
            var safePosition = this.calculateInitialSafePosition(newVehicle, gameCanvas);
            this.adjustPositionForExistingVehicles(newVehicle, ref safePosition, gameCanvas);
            return safePosition;
        }

        private double calculateInitialSafePosition(Vehicle vehicle, Canvas gameCanvas)
        {
            if (this.MoveDirection == Direction.Left)
            {
                return gameCanvas.Width + BaseGap;
            }

            return -vehicle.Width;
        }

        private void adjustPositionForExistingVehicles(Vehicle newVehicle, ref double safePosition, Canvas gameCanvas)
        {
            foreach (var existingVehicle in this.VehiclesCopy)
            {
                this.adjustSafePositionForVehicle(newVehicle, existingVehicle, ref safePosition, gameCanvas);
            }
        }

        private void adjustSafePositionForVehicle(Vehicle newVehicle, Vehicle existingVehicle, ref double safePosition,
            Canvas gameCanvas)
        {
            var minSafeDistance = newVehicle.Width + BaseGap;

            if (this.MoveDirection == Direction.Left)
            {
                this.adjustPositionForLeftDirection(existingVehicle, ref safePosition, minSafeDistance,
                    gameCanvas.Width);
            }
            else
            {
                this.adjustPositionForRightDirection(newVehicle, existingVehicle, ref safePosition, minSafeDistance,
                    gameCanvas.Width);
            }
        }

        private void adjustPositionForLeftDirection(Vehicle existingVehicle,
            ref double safePosition, double minSafeDistance, double canvasWidth)
        {
            var existingVehiclePosition = existingVehicle.XLocation;
            var existingVehicleEnd = existingVehiclePosition + existingVehicle.Width;

            if (safePosition + existingVehicleEnd < minSafeDistance)
            {
                safePosition = existingVehicleEnd + minSafeDistance;
            }

            if (existingVehiclePosition > canvasWidth)
            {
                this.wrapPosition(ref safePosition, existingVehiclePosition, minSafeDistance, canvasWidth);
            }
        }

        private void adjustPositionForRightDirection(Vehicle newVehicle, Vehicle existingVehicle,
            ref double safePosition, double minSafeDistance, double canvasWidth)
        {
            var existingVehiclePosition = existingVehicle.XLocation;
            var existingVehicleEnd = existingVehiclePosition + existingVehicle.Width;

            if (existingVehiclePosition - safePosition < minSafeDistance)
            {
                safePosition = existingVehiclePosition - newVehicle.Width - minSafeDistance;
            }

            if (existingVehicleEnd < 0)
            {
                this.wrapPosition(ref safePosition, existingVehicleEnd, minSafeDistance, canvasWidth, false);
            }
        }

        private void wrapPosition(ref double safePosition, double vehiclePosition, double minSafeDistance,
            double canvasWidth, bool isLeftDirection = true)
        {
            var wrappedPosition = isLeftDirection ? vehiclePosition - canvasWidth : vehiclePosition + canvasWidth;

            if ((isLeftDirection && wrappedPosition < safePosition &&
                 safePosition - wrappedPosition < minSafeDistance) ||
                (!isLeftDirection && wrappedPosition > safePosition &&
                 wrappedPosition - safePosition < minSafeDistance))
            {
                safePosition = wrappedPosition +
                               (isLeftDirection ? canvasWidth + minSafeDistance : -VehicleSpread - minSafeDistance);
            }
        }

        /// <summary>
        ///     Places a specified number of vehicles of the given type in the lane.
        /// </summary>
        /// <param name="gameCanvas">The canvas where the vehicles will be placed.</param>
        /// <param name="numberOfVehicles">The number of vehicles to place in the lane.</param>
        /// <param name="type">The type of vehicles to place in the lane.</param>
        /// <param name="direction">The direction in which the vehicles should move.</param>
        public void PlaceVehicles(Canvas gameCanvas, int numberOfVehicles, Vehicle.VehicleType type,
            Direction direction)
        {
            this.GameCanvasReference = gameCanvas;

            for (var i = 0; i < numberOfVehicles; i++)
            {
                var vehicle = new Vehicle(type)
                {
                    MoveDirection = direction,
                    XLocation = direction == Direction.Left ? gameCanvas.Width + VehicleSpread : -VehicleSpread
                };
                this.AddVehicle(vehicle, gameCanvas);
            }
        }

        /// <summary>
        ///     Moves all the vehicles in the lane.
        /// </summary>
        public void MoveVehicles()
        {
            foreach (var vehicle in this.Vehicles)
            {
                vehicle.SetSpeed(this.Speed, 0);
                vehicle.MoveGameObject(vehicle.MoveDirection, this.Speed);
            }
        }

        /// <summary>
        ///     Resets and removes vehicles in a lane
        /// </summary>
        public void Reset()
        {
            foreach (var vehicle in this.VehiclesCopy)
            {
                this.GameCanvasReference.Children.Remove(vehicle.Sprite);
            }

            this.VehiclesCopy.Clear();
        }
    }
}