﻿using System;
using Windows.Foundation;
using Windows.UI.Xaml;
using Frogger.View.Sprites;

namespace Frogger.Model
{
    /// <summary>
    ///     Defines basic properties and behavior of every game object.
    /// </summary>
    public abstract class GameObject
    {
        #region Data members

        private Point location;

        /// <summary>
        ///     Background width constant.
        /// </summary>
        public double BackgroundWidth = (double)Application.Current.Resources["AppWidth"];

        /// <summary>
        ///     Background height constant.
        /// </summary>
        public double BackgroundHeight = (double)Application.Current.Resources["AppHeight"];

        /// <summary>
        ///     High shoulder Y location constant.
        /// </summary>
        public double HighShoulderYLocation = (double)Application.Current.Resources["HighShoulderYLocation"];

        /// <summary>
        ///     Low shoulder Y location constant.
        /// </summary>
        public double LowShoulderYLocation = (double)Application.Current.Resources["LowShoulderYLocation"];

        #endregion

        #region Enums

        /// <summary>
        ///     Enumeration representing movement directions.
        /// </summary>
        public enum Direction
        {
            /// <summary>
            ///     Right direction enum
            /// </summary>
            Right,

            /// <summary>
            ///     Left direction enum
            /// </summary>
            Left,

            /// <summary>
            ///     Up direction enum
            /// </summary>
            Up,

            /// <summary>
            ///     Down direction enum
            /// </summary>
            Down
        }

        #endregion

        #region Properties

        /// <summary>
        ///     Gets or sets the x location of the game object.
        /// </summary>
        /// <value>
        ///     The x.
        /// </value>
        public double XLocation
        {
            get => this.location.X;
            set
            {
                this.location.X = value;
                this.render();
            }
        }

        /// <summary>
        ///     Gets or sets the y location of the game object.
        /// </summary>
        /// <value>
        ///     The y.
        /// </value>
        public double YLocation
        {
            get => this.location.Y;
            set
            {
                this.location.Y = value;
                this.render();
            }
        }

        /// <summary>
        ///     Gets the x speed of the game object.
        /// </summary>
        /// <value>
        ///     The speed x.
        /// </value>
        public double SpeedX { get; set; }

        /// <summary>
        ///     Gets the y speed of the game object.
        /// </summary>
        /// <value>
        ///     The speed y.
        /// </value>
        public double SpeedY { get; private set; }

        /// <summary>
        ///     Gets or Sets the width of the game object.
        /// </summary>
        /// <value>
        ///     The width.
        /// </value>
        public double Width
        {
            get => this.Sprite.Width;
            set => this.Sprite.Width = value;
        }

        /// <summary>
        ///     Gets the height of the game object.
        /// </summary>
        /// <value>
        ///     The height.
        /// </value>
        public double Height => this.Sprite.Height;

        /// <summary>
        ///     Gets or sets the sprite associated with the game object.
        /// </summary>
        /// <value>
        ///     The sprite.
        /// </value>
        public BaseSprite Sprite { get; set; }

        #endregion

        #region Methods

        /// <summary>
        ///     Moves the game object in the specified direction by a certain distance.
        /// </summary>
        /// <param name="direction">The direction in which to move the game object.</param>
        /// <param name="distance">The distance by which to move the game object.</param>
        public virtual void MoveGameObject(Direction direction, double distance)
        {
            switch (direction)
            {
                case Direction.Right:
                    this.moveX(distance);
                    break;

                case Direction.Left:
                    this.moveX(-distance);
                    break;

                case Direction.Up:
                    this.moveY(-distance);
                    break;

                case Direction.Down:
                    this.moveY(distance);
                    break;

                default:
                    throw new ArgumentOutOfRangeException(nameof(direction), "Invalid direction.");
            }
        }

        private void moveX(double x)
        {
            this.XLocation += x;
        }

        private void moveY(double y)
        {
            this.YLocation += y;
        }

        private void render()
        {
            this.Sprite.RenderAt(this.XLocation, this.YLocation);
        }

        /// <summary>
        ///     Sets the speed of the game object.
        ///     Precondition: speedX >= 0 AND speedY >=0
        ///     Post-condition: SpeedX == speedX AND SpeedY == speedY
        /// </summary>
        /// <param name="speedX">The speed x.</param>
        /// <param name="speedY">The speed y.</param>
        public void SetSpeed(double speedX, int speedY)
        {
            if (speedX < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(speedX));
            }

            if (speedY < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(speedY));
            }

            this.SpeedX = speedX;
            this.SpeedY = speedY;
        }

        /// <summary>
        ///     Checks for collision between this game object and another game object.
        /// </summary>
        /// <param name="other">The other game object to check collision against.</param>
        /// <returns>True if a collision is detected; otherwise, false.</returns>
        public bool CollisionOccurred(GameObject other)
        {
            var rectangle1 = new Rect(this.XLocation, this.YLocation, this.Width, this.Height);
            var rectangle2 = new Rect(other.XLocation, other.YLocation, other.Width, other.Height);

            return rectangle1.Left < rectangle2.Right &&
                   rectangle1.Right > rectangle2.Left &&
                   rectangle1.Top < rectangle2.Bottom &&
                   rectangle1.Bottom > rectangle2.Top;
        }

        #endregion
    }
}