﻿using System;

namespace Frogger.Model
{
    /// <summary>
    ///     Represents a high score entry for the game.
    /// </summary>
    public class HighScore
    {
        /// <summary>
        ///     Gets or sets the name of the player.
        /// </summary>
        /// <value>
        ///     The name of the player associated with the high score.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets the score achieved by the player.
        /// </summary>
        /// <value>
        ///     The score value. This property is read-only.
        /// </value>
        public int Score { get; private set; }

        /// <summary>
        ///     Gets the number of levels completed by the player.
        /// </summary>
        /// <value>
        ///     The count of levels completed. This property is read-only.
        /// </value>
        public int LevelsCompleted { get; private set; }

        /// <summary>
        ///     Initializes a new instance of the <see cref="HighScore" /> class.
        /// </summary>
        /// <param name="name">The name of the player.</param>
        /// <param name="score">The score achieved by the player.</param>
        /// <param name="levelsCompleted">The number of levels completed by the player.</param>
        /// <exception cref="ArgumentException">
        ///     Thrown when the <paramref name="name" /> is null or empty, or
        ///     the <paramref name="score" /> is negative.
        /// </exception>
        public HighScore(string name, int score, int levelsCompleted)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentException("Name cannot be null or empty.");
            }

            if (score < 0)
            {
                throw new ArgumentException("Score cannot be negative.");
            }

            this.Name = name;
            this.Score = score;
            this.LevelsCompleted = levelsCompleted;
        }
    }
}