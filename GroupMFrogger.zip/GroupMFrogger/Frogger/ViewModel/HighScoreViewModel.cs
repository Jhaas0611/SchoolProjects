﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using Windows.ApplicationModel.Core;
using Frogger.Command;
using Frogger.Controller;
using Frogger.FileIO;
using Frogger.Model;

namespace Frogger.ViewModel
{
    /// <summary>
    ///     ViewModel for managing high scores in the Frogger game.
    /// </summary>
    public class HighScoreViewModel : INotifyPropertyChanged
    {
        #region Data members

        private readonly GameManager gameManager;

        private ObservableCollection<HighScore> observableHighScores;

        private bool isHighScoreSelected;

        private HighScore selectedHighScore;

        private string editedName;

        #endregion

        #region Properties

        /// <summary>
        ///     Gets or sets the collection of high scores.
        /// </summary>
        public ObservableCollection<HighScore> HighScores
        {
            get => this.observableHighScores;
            set
            {
                this.observableHighScores = value;
                this.notifyPropertyChanged(nameof(this.HighScores));
            }
        }

        /// <summary>
        ///     Gets or sets a value indicating whether a high score is selected.
        /// </summary>
        public bool IsHighScoreSelected
        {
            get => this.isHighScoreSelected;
            set
            {
                this.isHighScoreSelected = value;
                this.notifyPropertyChanged(nameof(this.IsHighScoreSelected));
            }
        }

        /// <summary>
        ///     Gets or sets the currently selected high score.
        /// </summary>
        public HighScore SelectedHighScore
        {
            get => this.selectedHighScore;
            set
            {
                this.selectedHighScore = value;
                this.notifyPropertyChanged(nameof(this.SelectedHighScore));
                this.RemoveScoreCommand.RaiseCanExecuteChanged();
                this.EditScoreNameCommand.RaiseCanExecuteChanged();
                this.IsHighScoreSelected = value != null;
            }
        }

        /// <summary>
        ///     Gets or sets the edited name for a high score.
        /// </summary>
        public string EditedName
        {
            get => this.editedName;
            set
            {
                this.editedName = value;
                this.notifyPropertyChanged(nameof(this.EditedName));
            }
        }

        /// <summary>
        ///     Command to reset the game.
        /// </summary>
        public RelayCommand ResetGameCommand { get; set; }

        /// <summary>
        ///     Command to sort high scores by name.
        /// </summary>
        public RelayCommand SortByNameCommand { get; set; }

        /// <summary>
        ///     Command to sort high scores by score.
        /// </summary>
        public RelayCommand SortByScoreCommand { get; set; }

        /// <summary>
        ///     Command to sort high scores by level.
        /// </summary>
        public RelayCommand SortByLevelCommand { get; set; }

        /// <summary>
        ///     Command to remove a selected high score.
        /// </summary>
        public RelayCommand RemoveScoreCommand { get; set; }

        /// <summary>
        ///     Command to edit the name of a selected high score.
        /// </summary>
        public RelayCommand EditScoreNameCommand { get; set; }

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the HighScoreViewModel class with a reference to a GameManager.
        /// </summary>
        /// <param name="gameManager">The game manager instance to manage game-related data and actions.</param>
        public HighScoreViewModel(GameManager gameManager)
        {
            this.gameManager = gameManager;
            this.observableHighScores = new ObservableCollection<HighScore>();
            this.loadCommands();
            this.loadHighScores();
        }

        /// <summary>
        ///     Initializes a new instance of the HighScoreViewModel class without a game manager. Default constructor needed for
        ///     binding.
        /// </summary>
        public HighScoreViewModel()
        {
            this.observableHighScores = new ObservableCollection<HighScore>();
            this.loadCommands();
            this.loadHighScores();
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Occurs when a property value changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        ///     Sorts the high scores by name then score then level.
        /// </summary>
        private void sortByName(object obj)
        {
            Debug.WriteLine(this.HighScores.Count + "");
            var sorted = this.HighScores.OrderBy(hs => hs.Name).ThenBy(hs => hs.Score).ThenBy(hs => hs.LevelsCompleted)
                .ToList();
            this.updateObservableCollection(sorted);
        }

        /// <summary>
        ///     Sorts the high scores by score then name then level.
        /// </summary>
        private void sortByScore(object obj)
        {
            var sorted = this.HighScores.OrderByDescending(hs => hs.Score).ThenBy(hs => hs.Name)
                .ThenBy(hs => hs.LevelsCompleted).ToList();
            this.updateObservableCollection(sorted);
        }

        /// <summary>
        ///     Sorts the high scores by level then score then name.
        /// </summary>
        private void sortByLevel(object obj)
        {
            var sorted = this.HighScores.OrderByDescending(hs => hs.LevelsCompleted)
                .ThenBy(hs => hs.Score)
                .ThenBy(hs => hs.Name)
                .ToList();
            this.updateObservableCollection(sorted);
        }

        /// <summary>
        ///     Updates the observable collection of high scores.
        /// </summary>
        /// <param name="sorted">The list of sorted high scores.</param>
        private void updateObservableCollection(List<HighScore> sorted)
        {
            this.observableHighScores.Clear();
            foreach (var score in sorted)
            {
                this.observableHighScores.Add(score);
            }

            this.SortByLevelCommand.RaiseCanExecuteChanged();
            this.SortByNameCommand.RaiseCanExecuteChanged();
            this.SortByScoreCommand.RaiseCanExecuteChanged();
        }

        /// <summary>
        ///     Loads high scores from the persistent storage.
        /// </summary>
        private async void loadHighScores()
        {
            var loadedHighScores = await AppDataReaderWriter.ReadHighScoresAsync();
            foreach (var highScore in loadedHighScores)
            {
                this.observableHighScores.Add(highScore);
            }

            this.sortByScore(null);

            this.SortByLevelCommand.RaiseCanExecuteChanged();
            this.SortByNameCommand.RaiseCanExecuteChanged();
            this.SortByScoreCommand.RaiseCanExecuteChanged();
        }

        /// <summary>
        ///     Initializes commands used by the ViewModel.
        /// </summary>
        private void loadCommands()
        {
            this.ResetGameCommand = new RelayCommand(this.resetGame, this.canResetGame);
            this.SortByLevelCommand = new RelayCommand(this.sortByLevel, this.canSortScores);
            this.SortByNameCommand = new RelayCommand(this.sortByName, this.canSortScores);
            this.SortByScoreCommand = new RelayCommand(this.sortByScore, this.canSortScores);
            this.RemoveScoreCommand = new RelayCommand(this.removeScoreAsync, this.canModifyScore);
            this.EditScoreNameCommand = new RelayCommand(this.editScoreNameAsync, this.canModifyScore);
        }

        private bool canModifyScore(object obj)
        {
            return this.SelectedHighScore != null;
        }

        private async void removeScoreAsync(object parameter)
        {
            if (this.SelectedHighScore != null)
            {
                this.HighScores.Remove(this.SelectedHighScore);
            }

            this.SortByLevelCommand.RaiseCanExecuteChanged();
            this.SortByNameCommand.RaiseCanExecuteChanged();
            this.SortByScoreCommand.RaiseCanExecuteChanged();

            await AppDataReaderWriter.WriteHighScoresToFileAsync(this.HighScores);
        }

        private async void editScoreNameAsync(object parameter)
        {
            if (this.SelectedHighScore != null && !string.IsNullOrWhiteSpace(this.EditedName))
            {
                var updatedHighScore = new HighScore(this.EditedName, this.SelectedHighScore.Score,
                    this.SelectedHighScore.LevelsCompleted);

                var index = this.HighScores.IndexOf(this.SelectedHighScore);
                if (index != -1)
                {
                    this.HighScores[index] = updatedHighScore;

                    this.EditedName = string.Empty;
                    this.notifyPropertyChanged(nameof(this.HighScores));

                    await AppDataReaderWriter.WriteHighScoresToFileAsync(this.HighScores);
                }
            }
        }

        private bool canSortScores(object obj)
        {
            return this.HighScores.Count > 0;
        }

        private async void resetGame(object obj)
        {
            var result = await CoreApplication.RequestRestartAsync("");

            if (result == AppRestartFailureReason.NotInForeground || result == AppRestartFailureReason.Other)
            {
                throw new InvalidOperationException("App restart failed");
            }
        }

        private bool canResetGame(object obj)
        {
            return true;
        }

        private void notifyPropertyChanged(string propertyName)
        {
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        ///     Creates a new high score entry.
        /// </summary>
        /// <param name="playerName">Name of the player.</param>
        public async void CreateHighScore(string playerName)
        {
            var playerScore = this.gameManager.GetCurrentScore();
            var levelsCompleted = this.gameManager.GetLevelsCompleted();
            var newHighScore = new HighScore(playerName, playerScore, levelsCompleted);
            this.HighScores.Add(newHighScore);

            await AppDataReaderWriter.WriteHighScoresToFileAsync(this.HighScores);

            this.notifyPropertyChanged("HighScoreCreated");
        }

        /// <summary>
        ///     Resets the existing High Scores
        /// </summary>
        public async void ResetHighScores()
        {
            this.HighScores.Clear();
            await AppDataReaderWriter.WriteHighScoresToFileAsync(this.HighScores);
        }

        #endregion
    }
}