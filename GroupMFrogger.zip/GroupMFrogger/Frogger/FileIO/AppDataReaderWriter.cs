﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
using Frogger.Model;

namespace Frogger.FileIO
{
    /// <summary>
    ///     Provides functionality for reading and writing high scores to and from a file.
    /// </summary>
    public class AppDataReaderWriter
    {
        /// <summary>
        ///     Writes a collection of high scores to a CSV file asynchronously.
        /// </summary>
        /// <param name="highScores">The collection of high scores to write to the file.</param>
        /// <returns>A task that represents the asynchronous write operation.</returns>
        /// <remarks>
        ///     This method creates or replaces the existing "HighScores.csv" file with the new high scores.
        ///     Each high score is written as a line in the format "Name,Score,LevelsCompleted".
        /// </remarks>
        public static async Task WriteHighScoresToFileAsync(ObservableCollection<HighScore> highScores)
        {
            var localFolder = ApplicationData.Current.LocalFolder;
            var highScoreFile =
                await localFolder.CreateFileAsync("HighScores.csv", CreationCollisionOption.ReplaceExisting);

            var stringBuilder = new StringBuilder();
            foreach (var highScore in highScores)
            {
                stringBuilder.AppendLine($"{highScore.Name},{highScore.Score},{highScore.LevelsCompleted}");
            }

            await Windows.Storage.FileIO.WriteTextAsync(highScoreFile, stringBuilder.ToString());
        }

        /// <summary>
        ///     Reads high scores from a CSV file asynchronously.
        /// </summary>
        /// <returns>
        ///     A task that represents the asynchronous read operation.
        ///     The task result contains a list of high scores read from the file.
        /// </returns>
        /// <remarks>
        ///     Reads the "HighScores.csv" file and parses each line into a HighScore object.
        ///     If the file is not found, an empty list is returned.
        /// </remarks>
        public static async Task<List<HighScore>> ReadHighScoresAsync()
        {
            var highScores = new List<HighScore>();
            var localFolder = ApplicationData.Current.LocalFolder;

            try
            {
                var highScoreFile = await localFolder.GetFileAsync("HighScores.csv");
                var lines = await Windows.Storage.FileIO.ReadLinesAsync(highScoreFile);

                foreach (var line in lines)
                {
                    var parts = line.Split(',');
                    if (parts.Length >= 3)
                    {
                        var name = parts[0];
                        int.TryParse(parts[1], out var score);
                        int.TryParse(parts[2], out var levelsCompleted);
                        highScores.Add(new HighScore(name, score, levelsCompleted));
                    }
                }
            }
            catch (FileNotFoundException)
            {
                Debug.WriteLine("HighScores.csv not found.");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception while reading high scores: " + ex.Message);
            }

            return highScores;
        }
    }
}