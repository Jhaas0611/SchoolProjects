﻿using System;
using Windows.ApplicationModel.Core;
using Windows.Foundation;
using Windows.System;
using Windows.UI.Core;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Frogger.Controller;
using Frogger.ViewModel;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Frogger.View
{
    /// <summary>
    ///     An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class GamePage
    {
        #region Data members

        private const int ButtonZIndex = 1;

        private readonly double applicationHeight = (double)Application.Current.Resources["AppHeight"];
        private readonly double applicationWidth = (double)Application.Current.Resources["AppWidth"];
        private GameManager gameManager;
        private readonly GameHud gameHud;
        private HighScoreViewModel highScoreViewModel;

        #endregion

        #region Constructors

        /// <summary>
        ///     The "main" page for the Frogger game.
        /// </summary>
        public GamePage()
        {
            this.InitializeComponent();
            ApplicationView.PreferredLaunchViewSize = new Size
                { Width = this.applicationWidth, Height = this.applicationHeight };
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;
            ApplicationView.GetForCurrentView()
                ?.SetPreferredMinSize(new Size(this.applicationWidth, this.applicationHeight));

            Window.Current.CoreWindow.KeyDown += this.coreWindowOnKeyDown;
            this.gameHud = new GameHud(this.livesTextBlock, this.scoreTextBlock, this.gameOverTextBlock,
                this.timerTextBlock, this.levelTextBlock, this.uncrushableTextBlock);
            this.highScoreViewModel = new HighScoreViewModel(this.gameManager);
            this.setupGameButtons();
        }

        #endregion

        #region Methods

        private void setupGameButtons()
        {
            this.tryAgainButton.IsEnabled = false;
            this.tryAgainButton.Visibility = Visibility.Collapsed;
            this.enterHighScoreButton.IsEnabled = false;
            this.enterHighScoreButton.Visibility = Visibility.Collapsed;
            this.scoreNameTextBox.IsEnabled = false;
            this.scoreNameTextBox.Visibility = Visibility.Collapsed;
            Canvas.SetZIndex(this.startButton, ButtonZIndex);
            Canvas.SetZIndex(this.tryAgainButton, ButtonZIndex);
            Canvas.SetZIndex(this.highScoreButton, ButtonZIndex);
        }

        private void coreWindowOnKeyDown(CoreWindow sender, KeyEventArgs args)
        {
            switch (args.VirtualKey)
            {
                case VirtualKey.Left:
                    this.gameManager.MovePlayerLeft();
                    break;
                case VirtualKey.Right:
                    this.gameManager.MovePlayerRight();
                    break;
                case VirtualKey.Up:
                    this.gameManager.MovePlayerUp();
                    break;
                case VirtualKey.Down:
                    this.gameManager.MovePlayerDown();
                    break;
            }
        }

        private void startButton_Click(object sender, RoutedEventArgs e)
        {
            this.gameManager = new GameManager(this.applicationHeight, this.applicationWidth);
            
            DataContext = this.highScoreViewModel;
            this.gameHud.UpdateLives(4);
            this.gameHud.UpdateScore(0);
            this.gameHud.UpdateLevel(1);
            this.gameManager.OnScoreChanged += this.gameHud.UpdateScore;
            this.gameManager.OnLivesChanged += this.gameHud.UpdateLives;
            this.gameManager.OnTimerChanged += this.gameHud.UpdateTimer;
            this.gameManager.OnLevelChanged += this.gameHud.UpdateLevel;
            this.gameManager.OnUncrushableTimerChanged += this.gameHud.UpdateUncrushability;
            this.gameManager.OnGameOver += this.handleGameOver;
            this.gameManager.InitializeGame(this.canvas);
            this.disableButtons();
        }

        private void highScoreButton_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(HighScoreBoardPage));
        }

        private void disableButtons()
        {
            this.startButton.IsEnabled = false;
            this.startButton.Visibility = Visibility.Collapsed;
            this.highScoreButton.IsEnabled = false;
            this.highScoreButton.Visibility = Visibility.Collapsed;
            this.tryAgainButton.IsEnabled = false;
            this.tryAgainButton.Visibility = Visibility.Collapsed;
        }

        private void tryAgainButton_Click(object sender, RoutedEventArgs e)
        {
            this.restartApp();
        }

        private async void restartApp()
        {

            var result = await CoreApplication.RequestRestartAsync("");

            if (result == AppRestartFailureReason.NotInForeground || result == AppRestartFailureReason.Other)
            {
                throw new InvalidOperationException("App restart failed");
            }
        }

        private void handleGameOver()
        {
            this.gameHud.ShowGameOverMessage();
            this.enableGameOverButtons();
            this.uncrushableTextBlock.Visibility = Visibility.Collapsed;
        }

        private void enableGameOverButtons()
        {
            this.tryAgainButton.IsEnabled = true;
            this.tryAgainButton.Visibility = Visibility.Visible;
            this.highScoreButton.Visibility = Visibility.Visible;
            this.highScoreButton.IsEnabled = true;
            this.scoreNameTextBox.IsEnabled = true;
            this.scoreNameTextBox.Visibility = Visibility.Visible;
            this.enterHighScoreButton.Visibility = Visibility.Visible;
        }

        private void enterHighScoreButton_Click(object sender, RoutedEventArgs e)
        {
            var playerName = this.scoreNameTextBox.Text;
            this.highScoreViewModel.CreateHighScore(playerName);

            this.enterHighScoreButton.Visibility = Visibility.Collapsed;
            this.scoreNameTextBox.Visibility = Visibility.Collapsed;
        }

        private void scoreNameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            this.enterHighScoreButton.IsEnabled = !string.IsNullOrWhiteSpace(this.scoreNameTextBox.Text);
        }

        #endregion

        private void resetHighScoreButton_Click(object sender, RoutedEventArgs e)
        {
            this.highScoreViewModel.ResetHighScores();
        }
    }
}