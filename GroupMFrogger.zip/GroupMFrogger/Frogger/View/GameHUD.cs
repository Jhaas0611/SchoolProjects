﻿using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Frogger.View
{
    /// <summary>
    ///     Represents the Heads-Up Display (HUD) for the game, which displays lives, score, and game over messages.
    /// </summary>
    public class GameHud
    {
        #region Data members

        private readonly TextBlock livesTextBlock;
        private readonly TextBlock scoreTextBlock;
        private readonly TextBlock gameOverTextBlock;
        private readonly TextBlock timerTextBlock;
        private readonly TextBlock levelTextBlock;
        private readonly TextBlock uncrushableTextBlock;

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the GameHUD class.
        /// </summary>
        /// <param name="livesTextBlock">The TextBlock used to display remaining lives.</param>
        /// <param name="scoreTextBlock">The TextBlock used to display the player's score.</param>
        /// <param name="gameOverTextBlock">The TextBlock used to display the game over message.</param>
        /// <param name="timerTextBlock">The TextBlock used to display the timer on the game</param>
        /// <param name="levelTextBlock">The TextBlock used to display the level of the game</param>
        /// <param name="uncrushableTextBlock">The Text block used to display when the player is uncrushable</param>
        public GameHud(TextBlock livesTextBlock, TextBlock scoreTextBlock, TextBlock gameOverTextBlock,
            TextBlock timerTextBlock, TextBlock levelTextBlock, TextBlock uncrushableTextBlock)
        {
            this.livesTextBlock = livesTextBlock;
            this.scoreTextBlock = scoreTextBlock;
            this.gameOverTextBlock = gameOverTextBlock;
            this.timerTextBlock = timerTextBlock;
            this.levelTextBlock = levelTextBlock;
            this.uncrushableTextBlock = uncrushableTextBlock;
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Updates the display of remaining time.
        /// </summary>
        /// <param name="secondsRemaining"></param>
        public void UpdateTimer(int secondsRemaining)
        {
            this.timerTextBlock.Text = $"Timer: {secondsRemaining} seconds";
        }

        /// <summary>
        ///     Updates the display for remaining time on uncrushability
        /// </summary>
        /// <param name="secondsRemaining">time left uncrushable</param>
        public void UpdateUncrushability(int secondsRemaining)
        {
            if (secondsRemaining > 0)
            {
                this.uncrushableTextBlock.Visibility = Visibility.Visible;
                this.uncrushableTextBlock.Text = $"UNCRUSHABLE for {secondsRemaining} seconds!";
            }

            if (secondsRemaining == 0)
            {
                this.uncrushableTextBlock.Visibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        ///     Updates the display of remaining lives.
        /// </summary>
        /// <param name="lives">The number of lives to display.</param>
        public void UpdateLives(int lives)
        {
            this.livesTextBlock.Text = $"Lives: {lives}";
        }

        /// <summary>
        ///     Updates the display of the player's score.
        /// </summary>
        /// <param name="score">The player's current score.</param>
        public void UpdateScore(int score)
        {
            this.scoreTextBlock.Text = $"Score: {score}";
        }

        /// <summary>
        ///     Shows the game over message on the HUD.
        /// </summary>
        public void ShowGameOverMessage()
        {
            Canvas.SetZIndex(this.gameOverTextBlock, 1);
            this.gameOverTextBlock.Visibility = Visibility.Visible;
        }

        /// <summary>
        ///     Updates the level display
        /// </summary>
        /// <param name="level"> the current level</param>
        public void UpdateLevel(int level)
        {
            this.levelTextBlock.Text = $"Level: {level}";
        }

        #endregion
    }
}