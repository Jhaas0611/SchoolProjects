﻿// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Frogger.View
{
    /// <summary>
    ///     An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class HighScoreBoardPage
    {
        #region Constructors

        /// <summary>
        ///     The "main" page for the Frogger game.
        /// </summary>
        public HighScoreBoardPage()
        {
            this.InitializeComponent();
        }

        #endregion
    }
}