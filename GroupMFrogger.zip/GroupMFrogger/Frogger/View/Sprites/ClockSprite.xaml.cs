﻿// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace Frogger.View.Sprites
{
    /// <summary>
    ///     Draws the ClockSprite
    /// </summary>
    public sealed partial class ClockSprite
    {
        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="ClockSprite" /> class.
        /// </summary>
        public ClockSprite()
        {
            this.InitializeComponent();
        }

        #endregion
    }
}