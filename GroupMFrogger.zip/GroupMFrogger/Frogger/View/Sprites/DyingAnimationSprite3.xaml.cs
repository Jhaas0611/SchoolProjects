﻿// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace Frogger.View.Sprites
{
    /// <summary>
    ///     Represents a user control for part 3 of the dying animation sprite.
    /// </summary>
    public sealed partial class DyingAnimationSprite3
    {
        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the DyingAnimationSprite3 class.
        /// </summary>
        public DyingAnimationSprite3()
        {
            this.InitializeComponent();
        }

        #endregion
    }
}