﻿// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace Frogger.View.Sprites
{
    /// <summary>
    ///     Represents a user control for part 2 of the dying animation sprite.
    /// </summary>
    public sealed partial class DyingAnimationSprite2
    {
        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the DyingAnimationSprite2 class.
        /// </summary>
        public DyingAnimationSprite2()
        {
            this.InitializeComponent();
        }

        #endregion
    }
}