﻿

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace Frogger.View.Sprites
{
    /// <summary>
    /// Represents a user control for a truck sprite.
    /// </summary>
    public partial class LogSprite
    {

        /// <summary>
        /// Initializes a new instance of the TruckSprite class.
        /// </summary>
        public LogSprite()
        {
            this.InitializeComponent();
            this.Name = this.Name = "GameElement_LogSprite";
        }
    }
}
