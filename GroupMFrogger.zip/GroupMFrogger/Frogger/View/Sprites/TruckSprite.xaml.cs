﻿// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace Frogger.View.Sprites
{
    /// <summary>
    ///     Represents a user control for a truck sprite.
    /// </summary>
    public partial class TruckSprite
    {
        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the TruckSprite class.
        /// </summary>
        public TruckSprite()
        {
            this.InitializeComponent();
        }

        #endregion
    }
}