﻿// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace Frogger.View.Sprites
{
    /// <summary>
    ///     Draws the Moving FrogSprite
    /// </summary>
    public sealed partial class MovingFrogSprite
    {
        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="MovingFrogSprite" /> class.
        /// </summary>
        public MovingFrogSprite()
        {
            this.InitializeComponent();
        }

        #endregion
    }
}