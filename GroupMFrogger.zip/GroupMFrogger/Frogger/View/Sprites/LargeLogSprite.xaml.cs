﻿// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace Frogger.View.Sprites
{
    /// <summary>
    ///     Represents a user control for a LargeLog sprite.
    /// </summary>
    public partial class LargeLogSprite
    {
        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the LargeLogSprite class.
        /// </summary>
        public LargeLogSprite()
        {
            this.InitializeComponent();
        }

        #endregion
    }
}