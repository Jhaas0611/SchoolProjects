﻿using Windows.UI.Xaml;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace Frogger.View.Sprites
{
    /// <summary>
    ///     Represents the visual sprite for a safe zone in the game.
    /// </summary>
    public sealed partial class SafeZoneSprite
    {
        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="SafeZoneSprite" /> class.
        /// </summary>
        public SafeZoneSprite()
        {
            this.InitializeComponent();
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Displays an overlay indicating the safe zone has been visited.
        /// </summary>
        public void ShowVisitedOverlay()
        {
            this.visitedOverlay.Visibility = Visibility.Visible;
        }

        #endregion
    }
}