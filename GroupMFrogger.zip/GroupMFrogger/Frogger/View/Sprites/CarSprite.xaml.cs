﻿// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace Frogger.View.Sprites
{
    /// <summary>
    ///     Represents a user control for a car sprite.
    /// </summary>
    public partial class CarSprite
    {
        /// <summary>
        ///     Initializes a new instance of the CarSprite class.
        /// </summary>
        public CarSprite()
        {
            this.InitializeComponent();
        }
    }
}